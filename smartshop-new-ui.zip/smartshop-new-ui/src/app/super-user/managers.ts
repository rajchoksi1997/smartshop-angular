export class managers{
    userId:String;
    age:Number;
    gender:String;
    contactNumber:Number;

    constructor(){

    }


}